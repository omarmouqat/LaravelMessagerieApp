<?php
    use App\Models\User;
    use App\Models\Message;
?>

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Received Messages')); ?>

        </h2>

     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <ul role="list" class="divide-y divide-gray-100">
                        <?php echo e(__("Those are all the recieved messages !")); ?>

                        <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $message_writer = User::find($message->sender_id);
                            ?>
                            <?php if (isset($component)) { $__componentOriginal2342e1caa3b5224183b4572420a79d31 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2342e1caa3b5224183b4572420a79d31 = $attributes; } ?>
<?php $component = App\View\Components\Message::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Message::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                 <?php $__env->slot('sender_name', null, []); ?> 
                                    <?php echo e($message_writer->name); ?>

                                 <?php $__env->endSlot(); ?>
                                 <?php $__env->slot('sender_email', null, []); ?> 
                                    <?php echo e($message_writer->email); ?>

                                 <?php $__env->endSlot(); ?>
                                 <?php $__env->slot('objective', null, []); ?> 
                                    <?php echo e($message->objective); ?>

                                 <?php $__env->endSlot(); ?>
                                 <?php $__env->slot('type', null, []); ?> 
                                    <?php echo e("received"); ?>

                                 <?php $__env->endSlot(); ?>
                                 <?php $__env->slot('id_message', null, []); ?> 
                                    <?php echo e($message->id); ?>

                                 <?php $__env->endSlot(); ?>

                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2342e1caa3b5224183b4572420a79d31)): ?>
<?php $attributes = $__attributesOriginal2342e1caa3b5224183b4572420a79d31; ?>
<?php unset($__attributesOriginal2342e1caa3b5224183b4572420a79d31); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2342e1caa3b5224183b4572420a79d31)): ?>
<?php $component = $__componentOriginal2342e1caa3b5224183b4572420a79d31; ?>
<?php unset($__componentOriginal2342e1caa3b5224183b4572420a79d31); ?>
<?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </ul>

                </div>
                <br>
                <div class="p-2"><?php echo e($messages->links()); ?></div>

            </div>

        </div>

    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\user\Desktop\Gmail app\Gmail-App-Laravel\resources\views/received_messages.blade.php ENDPATH**/ ?>