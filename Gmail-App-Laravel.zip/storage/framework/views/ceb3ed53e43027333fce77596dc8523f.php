
<img src="<?php echo e(asset('images/my-logo.svg')); ?>" alt="My Logo" <?php echo e($attributes); ?>>
<?php /**PATH C:\Users\user\Desktop\Gmail app\Gmail-App-Laravel\resources\views/components/application-logo.blade.php ENDPATH**/ ?>