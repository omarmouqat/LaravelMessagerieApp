<?php
    use App\Models\User;
    use App\Models\Message;
?>

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('This is the content of the message!')); ?>

        </h2>

     <?php $__env->endSlot(); ?>
    <?php if($type=="sent"): ?>
        <div class="py-12">
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8" style="width: 60%">
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6 text-gray-900">
                        <h1 class="font-bold tracking-tight text-gray-900" style="font-size: 1.5rem"><?php echo e($message->objective); ?></h1>
                        <p class="text-xsm font-semibold leading-6 text-gray-400"><?php echo e(User::find($message->receiver_id)->email); ?></p>
                        <br>
                        <br>
                        <p class="text-xl font-semibold leading-6 text-gray-600"><?php echo e($message->message); ?></p>
                    </div>
                </div>

            </div>
            <hr>


        </div>
    <?php elseif($type=="received"): ?>
        <div class="py-12">
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8" style="width: 60%">
                <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div class="p-6 text-gray-900">
                        <h1 class="font-bold tracking-tight text-gray-900" style="font-size: 1.5rem"><?php echo e($message->objective); ?></h1>
                        <p class="text-xs font-semibold leading-6 text-gray-400"><?php echo e(User::find($message->sender_id)->email); ?></p>
                        <br>
                        <br>
                        <p class="text-xl font-semibold leading-6 text-gray-600"><?php echo e($message->message); ?></p>
                    </div>
                    <div class="m-6 flex items-center justify-end gap-x-2">
                        <a href="/send_message/<?php echo e($message->sender_id); ?>" class="rounded-md px-3 py-2 text-sm font-semibold text-white shadow-sm" style="background-color: rgb(78 69 228); margin: 10px">Answer <?php echo e(User::find($message->sender_id)->name); ?></a>
                    </div>
                </div>

            </div>

        </div>
    <?php endif; ?>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\user\Desktop\Gmail app\Gmail-App-Laravel\resources\views/show_message.blade.php ENDPATH**/ ?>